# Weeks 6-8 
# GUI Programming Assignment

from classes.config_application import *

Config_App()#Start main program