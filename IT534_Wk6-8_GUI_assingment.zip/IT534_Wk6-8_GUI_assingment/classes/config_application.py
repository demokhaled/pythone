from tkinter import *
from tkinter.ttk import *
from tkinter import filedialog, messagebox
import json

class Config_App():
    """Configuration application that simulates a helpdesk personnel's configuration suite
     for a server-side application that pulls its settings in from a JSON file"""

    def __init__(self):
        """Set up Configuration application"""
        self.my_app_window = Tk()
        self.my_app_window.geometry('340x450')
        self.possibleOptions = ['Application',
                                'Security', 'Error', 'Input/Output']
        self.possiblePorts = list(range(50000, 50501))
        self.setupInterface()

    def showConfig(self):
        """Shows all configuration controls"""

        # setup change-reflecting variables
        self.Threads = IntVar()
        self.debug = StringVar()

        # set some initial settings for the change-reflecting variables
        self.debug.set('On')
        self.Threads.set(1)

        # set up contols
        self.titleLabel = Label(self.my_app_window, text="Configuration",
                                relief=RIDGE, width=30, font="Arial", background="grey")
        self.titleLabel.grid(row=0, column=0, columnspan=8,
                             rowspan=2, sticky=NSEW)
        self.threadLabel = Label(
            self.my_app_window, text="Max threads:", font="Arial", foreground='green')
        self.threadLabel.grid(
            row=2, column=0, columnspan=6, rowspan=1, sticky=NSEW)

        # allow to choose 1, 2, or 4 only
        self.radioOption1 = Radiobutton(
            self.my_app_window, text=1, value=1, variable=self.Threads)
        self.radioOption2 = Radiobutton(
            self.my_app_window, text=2, value=2, variable=self.Threads)
        self.radioOption3 = Radiobutton(
            self.my_app_window, text=4, value=4, variable=self.Threads)

        self.radioOption1.grid(
            row=3, column=1, columnspan=2, rowspan=1, sticky=NSEW)
        self.radioOption2.grid(
            row=3, column=2, columnspan=2, rowspan=1, sticky=NSEW)
        self.radioOption3.grid(
            row=3, column=3, columnspan=2, rowspan=1, sticky=NSEW)

        self.eventLogPath = Entry(self.my_app_window)
        self.eventLabel = Label(
            self.my_app_window, text="Event Logfile:", font="Arial", foreground='green')
        self.eventLabel.grid(row=4, column=0, columnspan=8,
                             rowspan=1, sticky=NSEW)
        self.eventLogPath.grid(
            row=5, column=1, columnspan=2, rowspan=1, sticky=NSEW)
        self.eventLogPath.insert(END, "")

        self.eventTypesLabel = Label(
            self.my_app_window, text="Types of Events:", font="Arial", foreground='green')
        self.eventTypesLabel.grid(
            row=6, column=0, columnspan=8, rowspan=1, sticky=NSEW)

        self.eventTypesListBox = Listbox(
            self.my_app_window, selectmode="multiple", height=4, exportselection=False)
        self.eventTypesListBox.grid(
            row=7, column=1, columnspan=8, rowspan=1, sticky=NSEW)

        for each_item in range(len(self.possibleOptions)):
            self.eventTypesListBox.insert(END, self.possibleOptions[each_item])

        self.fileTypesLabel = Label(
            self.my_app_window, text="Supported File Types:", font="Arial", foreground='green')
        self.fileTypesLabel.grid(
            row=8, column=0, columnspan=8, rowspan=1, sticky=NSEW)

        self.FileExtensionsListBox = Listbox(
            self.my_app_window, selectmode="multiple", height=4, exportselection=False)  # Export selection?
        self.FileExtensionsListBox.grid(
            row=9, column=1, columnspan=7, rowspan=1, sticky=NSEW)

        self.extentionOptions = ['.doc', '.docx', '.ppt', '.pptx', '.xls', '.xslx', '.rtf',
                                 '.pdf', '.txt', '.jpg', '.png', '.gif', '.xml', '.html', '.zip', '.mp4', '.mov']
        self.scrollBar = Scrollbar(self.my_app_window, orient="vertical")
        self.scrollBar.config(command=self.FileExtensionsListBox.yview)
        self.scrollBar.grid(row=10, column=7, columnspan=1,
                            rowspan=1, sticky=NSEW)

        self.FileExtensionsListBox.config(yscrollcommand=self.scrollBar.set)
        for each_item_2 in range(0, len(self.extentionOptions)):
            self.FileExtensionsListBox.insert(
                END, self.extentionOptions[each_item_2])

        debugLabel = Label(self.my_app_window, text="Debug Mode:",
                           font="Arial", foreground='green')
        debugLabel.grid(row=10, column=0, columnspan=8, rowspan=1, sticky=NSEW)

        self.DebugRadioOn = Radiobutton(
            self.my_app_window, text='On', value='On', variable=self.debug)
        self.DebugRadioOn.grid(
            row=11, column=1, columnspan=2, rowspan=1, sticky=NSEW)

        self.DebugRadioOff = Radiobutton(
            self.my_app_window, text='Off', value='Off', variable=self.debug)
        self.DebugRadioOff.grid(
            row=11, column=3, columnspan=2, rowspan=1, sticky=NSEW)

        ServerLabel = Label(
            self.my_app_window, text="Server Port:", font="Arial", foreground='green')
        ServerLabel.grid(row=12, column=0, columnspan=8,
                         rowspan=1, sticky=NSEW)

        self.PortsComboBox = Combobox(
            self.my_app_window, values=self.possiblePorts)
        self.PortsComboBox.grid(
            row=13, column=1, columnspan=8, rowspan=1, sticky=NSEW)
        self.PortsComboBox.current(0)  # Set port to the first selected value

    def pullValuesFromControls(self):
        """Pull all the configuration values from user modified controls"""
        type_events = self.eventTypesListBox.curselection()
        file_types = self.FileExtensionsListBox.curselection()

        selectedOptions = []
        selectedExtentionOptions = []

        for index in type_events:
            selectedOptions.append(self.possibleOptions[index])
        for index in file_types:
            selectedExtentionOptions.append(self.extentionOptions[index])

        self.jsonData = {}
        self.jsonData['num_thread'] = self.Threads.get()
        self.jsonData['log_file_path'] = self.eventLogPath.get()
        self.jsonData['debug_mode'] = self.debug.get()
        self.jsonData['server_port'] = self.PortsComboBox.get()
        self.jsonData['event_types'] = selectedOptions
        self.jsonData['extension_options'] = selectedExtentionOptions

        return self.jsonData

    def save(self):
        """Save all the configuration values into program"""
        file = filedialog.asksaveasfile(mode='w', defaultextension=".json")
        if file is not None:
            json.dump(self.pullValuesFromControls(), file)
            file.close()
            messagebox.showinfo("Success", "Save Successfull.")

    def load(self):
        """Load json configuration file into the program and pre-set all of the form
        fields on the application to the values that are in the file you loaded."""
        file = filedialog.askopenfile(mode='r', filetypes=[(
            'Json Files', '*.json'), ('Json Files', '*.txt')])
        if file is not None:
            jsondata = json.load(file)
        try:
            self.Threads.set(int(jsondata['num_thread']))
            self.debug.set(jsondata['debug_mode'])
            self.eventLogPath.delete(0, END)
            self.eventLogPath.insert(0, jsondata['log_file_path'])
            ports = list(range(50000, 50501)).index(
                int(jsondata['server_port']))
            self.PortsComboBox.current(ports)
            for event in jsondata['event_types']:
                self.eventTypesListBox.selection_set(
                    self.possibleOptions.index(event))
            for types in jsondata['extension_options']:
                self.FileExtensionsListBox.selection_set(
                    self.extentionOptions.index(types))
            messagebox.showinfo("Success", "The json file has loaded.")
        except:
            messagebox.showerror("Error", "Failed to load json file.")

    def setupMenu(self):
        """Set up the top Saving and Loading Menu"""
        topMenu = Menu(self.my_app_window)
        self.my_app_window.config(menu=topMenu)
        drawFile = Menu(topMenu)
        drawFile.add_command(label="Load File", command=self.load)
        drawFile.add_command(label="Save File", command=self.save)
        topMenu.add_cascade(label="File", menu=drawFile)

    def setupInterface(self):
        """Set up all components of the interface"""
        self.my_app_window.title("Config App")
        self.showConfig()
        self.setupMenu()
        self.my_app_window.mainloop()
